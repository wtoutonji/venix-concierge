<?php
/**
 * Standard page.
 *
 * @package VenixConcierge
 */

get_header();
?>

<?php if ( is_page( 'about' ) ) : ?>
	<?php get_template_part( 'template-parts/sections/about' ); ?>
<?php else : ?>
	<main id="primary" class="site-main">
		<?php
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content/content', 'page' );
		endwhile;
		?>
	</main>
<?php endif; ?>

<?php
get_footer();
